# 3Bhai (Alpha build)

Three brothers. One kitchen. Zero food waste.
Flutter app (Android), Clean Architecture + BLoC/Cubit.

This alpha contains **only the UI with built-in sample data** (no backend, no API keys).

| Screen | Sample data |
|---|---|
| Login / Sign up | `MockAuthRepository` |
| Ingredients (99 items) | `MockIngredientRepository` |
| Recipe results (15 recipes, ranked) | `MockRecipeDataSource` + `mock_recipes.dart` |
| History (4 pre-filled searches) | `MockHistoryRepository` |
| Chef Bhai chat (pre-filled) | `MockChatRepository` |

**Demo login:** `chef@threebhai.app` / `Chef1234` (tap the banner on the login screen to fill it).
Any other valid email + password also works.

## Run
    flutter pub get
    flutter test
    flutter run
    flutter build apk --release

The first launch needs internet once, to download the app fonts.
The APK can also be built online by GitHub Actions (`.github/workflows/build.yml`).

## Structure
    lib/core/       theme, validators, failures, shared widgets
    lib/features/   auth, recipe, chat  (domain / data / presentation)
    test/           validators, cubits, ingredient catalog, alpha mock data
